package com.yagmur.controller;

import com.yagmur.service.ProductImagesService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequiredArgsConstructor
@RequestMapping("/product-images")
public class ProductImagesController {

    private final ProductImagesService productImagesService;

    @PostMapping("/upload/{productId}")
    public ResponseEntity<String> uploadImage(@RequestParam("file") MultipartFile file, @PathVariable Long productId) {
        try {
            productImagesService.saveImage(file, productId);
            return ResponseEntity.ok("Image uploaded successfully.");
        } catch (IOException e) {
            System.out.println(e.getMessage());
            return ResponseEntity.badRequest().body("Error uploading image.");
        }
    }

}
