package com.yagmur.repository;

import com.yagmur.entity.VirtualTryOnImage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VirtualTryOnImageRepository extends JpaRepository<VirtualTryOnImage, Long> {
}
