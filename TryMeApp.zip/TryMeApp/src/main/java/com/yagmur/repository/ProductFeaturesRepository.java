package com.yagmur.repository;

import com.yagmur.entity.ProductFeatures;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductFeaturesRepository extends JpaRepository<ProductFeatures, Long> {
}
