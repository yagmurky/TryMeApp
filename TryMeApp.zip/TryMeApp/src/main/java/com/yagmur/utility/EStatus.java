package com.yagmur.utility;

public enum EStatus {
    ACTIVE,
    INACTIVE,
    PENDING,
    DELETED
}
